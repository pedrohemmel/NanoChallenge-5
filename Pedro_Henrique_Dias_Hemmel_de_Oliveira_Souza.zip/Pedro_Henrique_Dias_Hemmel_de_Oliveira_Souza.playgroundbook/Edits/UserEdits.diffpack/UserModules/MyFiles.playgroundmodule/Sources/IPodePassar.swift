//Criando protocolo que vai ativar a função podePassar
protocol IPodePassar {
    func podePassar() -> Void
}
