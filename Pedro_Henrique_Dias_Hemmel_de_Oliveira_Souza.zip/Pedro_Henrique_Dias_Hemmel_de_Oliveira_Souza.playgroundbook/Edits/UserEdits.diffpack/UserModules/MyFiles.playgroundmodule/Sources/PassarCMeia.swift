public class PassarCMeia : IPodePassar {
    func podePassar() ->Void {
        show("Consegui passar pela catraca, passei pagando meia entrada!")
    }
}
