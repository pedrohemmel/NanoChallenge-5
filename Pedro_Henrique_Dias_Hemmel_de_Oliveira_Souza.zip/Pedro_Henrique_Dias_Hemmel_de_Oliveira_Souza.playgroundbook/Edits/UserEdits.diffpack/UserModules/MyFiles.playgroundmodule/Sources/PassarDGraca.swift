public class PassarDGraca : IPodePassar {
    func podePassar() -> Void {
        show("Consegui passar pela catraca, passei gratuitamente!")
    }
}
