public class PassarNaoPassar : IPodePassar {
    func podePassar() -> Void {
        show("Não consegui passar pela catraca, estou sem dinheiro.");
    }
} 
