public class PassarNormal : IPodePassar {
    func podePassar() ->Void {
        show("Consegui passar pela catraca, passei pagando uma entrada inteira!")
    }
}
