public class PassarNuloInicial : IPodePassar {
    func podePassar() -> Void {
        show("Por enquanto não sei como vou passar pela catraca do ônibus")
    }
}
